<?php
//Defines for a constant that the webpages are in development.
//If true the full exception will be generated on the webpage
//if false a user friendly error message will be displayed and a error_log generated
define("DEVELOPMENT", true);